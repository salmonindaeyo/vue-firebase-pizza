<script setup>
defineEmits(['deleteColor'])
defineProps({
    colorUserList: {
        type: Object,
        require: true,
    },
});
// const deleteAleart = () => {
//     alert('Delete Success !')

// }
</script>
 
<template>
        <button @click="$emit('deleteColor', colorUserList.id); "
            class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
            Delete</button>
</template>
 
<style>
</style>