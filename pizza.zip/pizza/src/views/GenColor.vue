<script setup>
import GenColorList from '../components/GenColorList.vue'
</script>
 
<template>
    <GenColorList />
</template>
<style>
#inputColor {
    -webkit-appearance: none;
    -moz-appearance: none;
    border: none;
    height: 70px;
    width: 70px;
    cursor: pointer;
}
</style>